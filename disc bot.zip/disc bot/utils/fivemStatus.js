const https = require('https');
const http = require('http');

async function getFiveMServerInfo(serverIp) {
  return new Promise((resolve, reject) => {
    // FiveM API endpoint
    const url = `http://${serverIp}/players.json`;
    const dynamicUrl = `http://${serverIp}/dynamic.json`;
    
    // Prvo dobij broj igrača
    http.get(url, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const players = JSON.parse(data);
          const currentPlayers = players.length;
          
          // Sada dobij max igrače
          http.get(dynamicUrl, (res2) => {
            let data2 = '';
            
            res2.on('data', (chunk) => {
              data2 += chunk;
            });
            
            res2.on('end', () => {
              try {
                const dynamic = JSON.parse(data2);
                const maxPlayers = dynamic.sv_maxclients || 32;
                const queue = 0; // FiveM ne daje queue info direktno
                
                resolve({
                  online: currentPlayers,
                  max: maxPlayers,
                  queue: queue
                });
              } catch (error) {
                resolve({
                  online: currentPlayers,
                  max: 32,
                  queue: 0
                });
              }
            });
          }).on('error', () => {
            resolve({
              online: currentPlayers,
              max: 32,
              queue: 0
            });
          });
          
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', (error) => {
      reject(error);
    });
  });
}

module.exports = { getFiveMServerInfo };
