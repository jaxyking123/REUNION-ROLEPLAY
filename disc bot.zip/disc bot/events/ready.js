const { REST, Routes } = require('discord.js');
const config = require('../config.json');
const fs = require('fs');
const { getFiveMServerInfo } = require('../utils/fivemStatus');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ Bot je online kao ${client.user.tag}`);
    console.log(`📝 Prefix komande su aktivne! Koristi ${config.prefix}start`);
    console.log(`🔒 Whitelist zaštita je aktivna!`);

    // Registruj slash komande
    const commands = [];
    const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
      const command = require(`../commands/${file}`);
      if (command.data) {
        commands.push(command.data.toJSON());
      }
    }

    if (commands.length > 0) {
      const rest = new REST({ version: '10' }).setToken(config.token);

      try {
        console.log('🔄 Registrujem slash komande...');
        await rest.put(
          Routes.applicationGuildCommands(config.clientId, config.guildId),
          { body: commands }
        );
        console.log('✅ Slash komande su registrovane!');
      } catch (error) {
        console.error('Greška pri registraciji komandi:', error);
      }
    }

    // FiveM status updater
    if (config.fivemServerIp && config.fivemServerIp !== 'YOUR_SERVER_IP:PORT') {
      updateFiveMStatus(client);
      setInterval(() => updateFiveMStatus(client), 60000); // Update svakih 60 sekundi
    }
  }
};

async function updateFiveMStatus(client) {
  try {
    const serverInfo = await getFiveMServerInfo(config.fivemServerIp);
    const status = `👥 ${serverInfo.online}/${serverInfo.max} | 🕐 Queue: ${serverInfo.queue}`;
    
    client.user.setPresence({
      activities: [{
        name: status,
        type: 3 // WATCHING
      }],
      status: 'online'
    });
    
    console.log(`🎮 FiveM Status ažuriran: ${status}`);
  } catch (error) {
    console.error('Greška pri ažuriranju FiveM statusa:', error.message);
    client.user.setPresence({
      activities: [{
        name: '❌ Server Offline',
        type: 3
      }],
      status: 'dnd'
    });
  }
}
