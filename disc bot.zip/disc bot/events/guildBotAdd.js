const fs = require('fs');
const path = require('path');
const config = require('../config.json');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    // Proveri da li je bot
    if (!member.user.bot) return;

    // Sačekaj malo da se audit log ažurira
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Učitaj whitelist
    const whitelistPath = path.join(__dirname, '../whitelist.json');
    let whitelist = { whitelistedUsers: [] };
    if (fs.existsSync(whitelistPath)) {
      whitelist = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
    }

    // Proveri audit log da vidiš ko je dodao bota
    try {
      const auditLogs = await member.guild.fetchAuditLogs({
        type: 28, // BOT_ADD
        limit: 5
      });

      const botAddLog = auditLogs.entries.find(entry => 
        entry.target.id === member.id && 
        Date.now() - entry.createdTimestamp < 3000
      );
      
      if (!botAddLog) {
        console.log('Audit log nije pronađen za bot add');
        return;
      }

      const executor = botAddLog.executor;
      
      console.log(`🤖 Bot dodat: ${executor.tag} dodao ${member.user.tag}`);
      
      // Proveri da li je executor whitelisted
      const isWhitelisted = whitelist.whitelistedUsers.includes(executor.id) || 
                           executor.id === member.guild.ownerId;

      if (isWhitelisted) {
        console.log(`✅ ${executor.tag} je whitelisted - bot dozvoljen`);
        return;
      }

      // Executor NIJE whitelisted - kickuj bota i kazni executora
      console.log(`⚠️ ${executor.tag} NIJE whitelisted - kickujem bota i kažnjavam!`);
      
      // Kickuj bota
      await member.kick('Neovlašćeno dodavanje bota').catch(err => console.log('Greška pri kickovanju bota:', err.message));
      console.log(`✅ Bot ${member.user.tag} kickovan`);
      
      // Kazni executora - ukloni SVE njegove role
      const executorMember = await member.guild.members.fetch(executor.id);
      const executorRoles = executorMember.roles.cache.filter(role => role.id !== member.guild.id);
      
      console.log(`🔨 Kažnjavam ${executor.tag} - uklanjam ${executorRoles.size} rola`);
      
      for (const role of executorRoles.values()) {
        await executorMember.roles.remove(role).catch(err => console.log('Greška:', err.message));
      }
      
      // Dodaj SAMO nuker rolu
      if (config.nukerRoleId && config.nukerRoleId !== 'NUKER_ROLE_ID_HERE') {
        await executorMember.roles.add(config.nukerRoleId).catch(err => console.log('Greška pri dodavanju nuker role:', err.message));
        console.log(`✅ Nuker rola dodata ${executor.tag}`);
      }
      
      // Pošalji DM
      try {
        await executor.send(`🤡 Dobar pokušaj retarde, više sreće na drugom serveru!\nSisaj kurac, moli opet za rollove!`);
      } catch (error) {
        console.log('Ne mogu poslati DM');
      }

      console.log(`✅ Kazna primenjena na ${executor.tag} - bot kickovan, sve role uklonjene, dodata nuker rola`);

    } catch (error) {
      console.error('Greška pri proveri bot add-a:', error);
    }
  }
};
