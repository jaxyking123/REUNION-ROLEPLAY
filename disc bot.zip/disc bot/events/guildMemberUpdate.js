const fs = require('fs');
const path = require('path');
const config = require('../config.json');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember) {
    // Sačekaj malo da se audit log ažurira
    await new Promise(resolve => setTimeout(resolve, 500));

    // Učitaj whitelist
    const whitelistPath = path.join(__dirname, '../whitelist.json');
    let whitelist = { whitelistedUsers: [] };
    if (fs.existsSync(whitelistPath)) {
      whitelist = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
    }

    // Proveri promene u rolama
    const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
    const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
    
    if (addedRoles.size === 0 && removedRoles.size === 0) return;

    try {
      // Proveri audit log
      const auditLogs = await newMember.guild.fetchAuditLogs({
        type: 25, // MEMBER_ROLE_UPDATE
        limit: 5
      });

      const relevantLog = auditLogs.entries.find(entry => 
        entry.target.id === newMember.id && 
        Date.now() - entry.createdTimestamp < 2000
      );

      if (!relevantLog) {
        console.log('Audit log nije pronađen za promenu rola');
        return;
      }

      const executor = relevantLog.executor;
      
      console.log(`📋 Role promena: ${executor.tag} -> ${newMember.user.tag}`);

      // Proveri da li je executor whitelisted
      const isWhitelisted = whitelist.whitelistedUsers.includes(executor.id) || 
                           executor.id === newMember.guild.ownerId || 
                           executor.bot;

      if (isWhitelisted) {
        console.log(`✅ ${executor.tag} je whitelisted`);
        return;
      }

      // Executor NIJE whitelisted - vrati promene žrtvi i kazni executora!
      console.log(`⚠️ ${executor.tag} NIJE whitelisted - vraćam role žrtvi i kažnjavam!`);

      // VRATI PROMENE ŽRTVI
      // Ako su dodane role, ukloni ih
      if (addedRoles.size > 0) {
        console.log(`🔄 Uklanjam ${addedRoles.size} dodanih rola od ${newMember.user.tag}`);
        for (const role of addedRoles.values()) {
          await newMember.roles.remove(role).catch(err => console.log('Greška pri uklanjanju role:', err.message));
        }
      }
      
      // Ako su uklonjene role, vrati ih
      if (removedRoles.size > 0) {
        console.log(`🔄 Vraćam ${removedRoles.size} uklonjenih rola ${newMember.user.tag}`);
        for (const role of removedRoles.values()) {
          await newMember.roles.add(role).catch(err => console.log('Greška pri vraćanju role:', err.message));
        }
      }

      console.log(`✅ Role vraćene žrtvi ${newMember.user.tag}`);

      // KAZNI EXECUTORA - ukloni SVE njegove role
      const executorMember = await newMember.guild.members.fetch(executor.id);
      const executorRoles = executorMember.roles.cache.filter(role => role.id !== newMember.guild.id);
      
      console.log(`🔨 Kažnjavam ${executor.tag} - uklanjam ${executorRoles.size} rola`);
      
      for (const role of executorRoles.values()) {
        await executorMember.roles.remove(role).catch(err => console.log('Greška:', err.message));
      }
      
      // Dodaj SAMO nuker rolu
      if (config.nukerRoleId && config.nukerRoleId !== 'NUKER_ROLE_ID_HERE') {
        await executorMember.roles.add(config.nukerRoleId).catch(err => console.log('Greška pri dodavanju nuker role:', err.message));
        console.log(`✅ Nuker rola dodata ${executor.tag}`);
      }
      
      // Pošalji DM
      try {
        await executor.send('🤡 Dobar pokušaj retarde, više sreće na drugom serveru!\nSisaj kurac, moli opet za rollove!');
      } catch (error) {
        console.log('Ne mogu poslati DM');
      }

      console.log(`✅ Kazna primenjena na ${executor.tag} - role vraćene žrtvi, sve role uklonjene executoru, dodata nuker rola`);

    } catch (error) {
      console.error('Greška u guildMemberUpdate:', error);
    }
  }
};
