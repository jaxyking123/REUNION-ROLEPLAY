const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const config = require('../config.json');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    console.log(`👤 Novi član: ${member.user.tag} (Bot: ${member.user.bot})`);
    
    const welcomeChannel = member.guild.channels.cache.get(config.welcomeChannelId);
    
    if (!welcomeChannel) {
      console.log(`❌ Welcome kanal nije pronađen! ID: ${config.welcomeChannelId}`);
      return;
    }

    console.log(`✅ Welcome kanal pronađen: ${welcomeChannel.name}`);

    // Proveri da li postoji lokalna slika
    let bannerUrl = null;
    let attachment = null;
    const localBannerPng = path.join(__dirname, '../assets/welcome-banner.png');
    const localBannerJpg = path.join(__dirname, '../assets/welcome-banner.jpg');
    
    if (fs.existsSync(localBannerPng)) {
      bannerUrl = 'attachment://welcome-banner.png';
      attachment = new AttachmentBuilder(localBannerPng);
      console.log('📷 Banner pronađen: welcome-banner.png');
    } else if (fs.existsSync(localBannerJpg)) {
      bannerUrl = 'attachment://welcome-banner.jpg';
      attachment = new AttachmentBuilder(localBannerJpg);
      console.log('📷 Banner pronađen: welcome-banner.jpg');
    } else {
      console.log('⚠️ Banner nije pronađen');
    }

    const embed = new EmbedBuilder()
      .setColor('#2B2D31')
      .setAuthor({ 
        name: '🎭 Reunion Roleplay', 
        iconURL: member.guild.iconURL({ dynamic: true })
      })
      .setTitle('**🎭 Pridruži se najboljem RP iskustvu na Balkanu! 🎭**')
      .setDescription(`
${member}

**Dobrodošao na Reunion Roleplay server u Grand Theft Auto V (FiveM)!**

Ako tražiš ozbiljan i kvalitetan roleplay, aktivnu zajednicu, unikatne poslove, realističnu ekonomiju i konstantne evente – ovo je pravo mjesto za tebe! 🚔💼🚑

🔹 Aktivna administracija
🔹 Legalni i ilegalni poslovi
🔹 Frakcije (Policija, Hitna, Mehaničari i još mnogo toga)
🔹 Redovni update-ovi i eventi

**Ne propusti priliku da postaneš dio priče – kreiraj svoj karakter i započni novu avanturu već danas na Reunion Roleplay! 🔥**

**Ti si naš ${member.guild.memberCount}. član!**
`)
      .setThumbnail(member.guild.iconURL({ dynamic: true, size: 256 }))
      .setFooter({ 
        text: '• Reunion Roleplay Staff', 
        iconURL: member.guild.iconURL({ dynamic: true })
      })
      .setTimestamp();

    // Dodaj sliku samo ako postoji
    if (bannerUrl) {
      embed.setImage(bannerUrl);
    }

    try {
      const messageOptions = { embeds: [embed] };
      
      if (attachment) {
        messageOptions.files = [attachment];
      }
      
      await welcomeChannel.send(messageOptions);
      console.log(`✅ Welcome poruka poslata za ${member.user.tag}`);
    } catch (error) {
      console.error('❌ Greška pri slanju welcome poruke:', error);
    }
  }
};
