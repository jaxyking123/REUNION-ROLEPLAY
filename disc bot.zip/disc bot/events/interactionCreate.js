const { ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');

const ticketReasons = {
  'ticket_admin': { emoji: '👮', name: 'Žalba na Admina', color: '#ED4245' },
  'ticket_player': { emoji: '🎮', name: 'Žalba na Igrača', color: '#5865F2' },
  'ticket_bug': { emoji: '🐛', name: 'Prijava Buga', color: '#57F287' },
  'ticket_question': { emoji: '❔', name: 'Pitanja', color: '#FEE75C' },
  'ticket_donation': { emoji: '💰', name: 'Donacija', color: '#FFD700' }
};

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    // Slash komande
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (error) {
        console.error(error);
        await interaction.reply({ content: '❌ Greška pri izvršavanju komande!', ephemeral: true });
      }
    }

    // Button interakcije
    if (interaction.isButton()) {
      // Ticketi sa razlozima
      if (interaction.customId.startsWith('ticket_')) {
        try {
          const guild = interaction.guild;
          const member = interaction.member;
          const reason = ticketReasons[interaction.customId];

          // Proveri da li korisnik već ima otvoren ticket
          const existingTicket = guild.channels.cache.find(
            ch => ch.name.startsWith(`ticket-${member.user.username.toLowerCase()}`) && ch.type === ChannelType.GuildText
          );

          if (existingTicket) {
            return interaction.reply({ 
              content: `❌ Već imaš otvoren ticket: ${existingTicket}`, 
              ephemeral: true 
            });
          }

          // Kreiraj ticket kanal
          const ticketType = interaction.customId.replace('ticket_', '');
          const categoryId = config.ticketCategories[ticketType] || null;
          const supportRoleId = config.ticketSupportRoles[ticketType] || config.supportRoleId;
          
          console.log(`Kreiram ticket tip: ${ticketType}, kategorija: ${categoryId}, support rola: ${supportRoleId}`);
          
          const permissionOverwrites = [
            {
              id: guild.id,
              deny: [PermissionFlagsBits.ViewChannel]
            },
            {
              id: member.id,
              allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
            }
          ];

          // Dodaj support rolu ako postoji
          if (supportRoleId && supportRoleId !== 'ADMIN_SUPPORT_ROLE_ID' && supportRoleId !== 'PLAYER_SUPPORT_ROLE_ID' && supportRoleId !== 'BUG_SUPPORT_ROLE_ID' && supportRoleId !== 'QUESTION_SUPPORT_ROLE_ID' && supportRoleId !== 'DONATION_SUPPORT_ROLE_ID') {
            permissionOverwrites.push({
              id: supportRoleId,
              allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
            });
          }
          
          const ticketChannel = await guild.channels.create({
            name: `ticket-${member.user.username}-${ticketType}`,
            type: ChannelType.GuildText,
            parent: categoryId,
            permissionOverwrites: permissionOverwrites
          });

          const embed = new EmbedBuilder()
            .setTitle(`${reason.emoji} ${reason.name}`)
            .setDescription(`Dobrodošao ${member}!\n\n**Razlog:** ${reason.name}\n\nOpiši detaljno svoj problem i naš support tim će ti uskoro odgovoriti.`)
            .setColor(reason.color)
            .setTimestamp();

          const closeButton = new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Zatvori Ticket')
            .setEmoji('🔒')
            .setStyle(ButtonStyle.Danger);

          const row = new ActionRowBuilder().addComponents(closeButton);

          await ticketChannel.send({ 
            content: `${member} ${supportRoleId && supportRoleId !== 'ADMIN_SUPPORT_ROLE_ID' && supportRoleId !== 'PLAYER_SUPPORT_ROLE_ID' && supportRoleId !== 'BUG_SUPPORT_ROLE_ID' && supportRoleId !== 'QUESTION_SUPPORT_ROLE_ID' && supportRoleId !== 'DONATION_SUPPORT_ROLE_ID' ? `<@&${supportRoleId}>` : ''}`, 
            embeds: [embed], 
            components: [row] 
          });

          await interaction.reply({ 
            content: `✅ Ticket kreiran: ${ticketChannel}`, 
            ephemeral: true 
          });
        } catch (error) {
          console.error('Greška pri kreiranju ticketa:', error);
          await interaction.reply({ 
            content: `❌ Greška pri kreiranju ticketa: ${error.message}`, 
            ephemeral: true 
          });
        }
      }

      if (interaction.customId === 'close_ticket') {
        const embed = new EmbedBuilder()
          .setTitle('🔒 Ticket Zatvoren')
          .setDescription(`Ticket zatvorio: ${interaction.user.tag}`)
          .setColor('#ED4245')
          .setTimestamp();

        await interaction.channel.send({ embeds: [embed] });
        await interaction.reply({ content: '⏳ Ticket će biti zatvoren za 5 sekundi...', ephemeral: true });

        setTimeout(() => {
          interaction.channel.delete();
        }, 5000);
      }
    }
  }
};
