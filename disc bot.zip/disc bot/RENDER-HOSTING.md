# Postavljanje bota na Render.com

## Korak 1: Napravi GitHub repo

1. Idi na https://github.com/new
2. Napravi novi repo (npr. "reunion-bot")
3. NE dodavaj README, .gitignore ili licencu

## Korak 2: Uploaduj kod na GitHub

Otvori Command Prompt u folderu bota i pokreni:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TVOJ-USERNAME/reunion-bot.git
git push -u origin main
```

## Korak 3: Napravi Render nalog

1. Idi na https://render.com
2. Klikni "Get Started" i prijavi se sa GitHub nalogom

## Korak 4: Deploy projekat

1. Klikni "New +" > "Background Worker" (VAŽNO: ne Web Service!)
2. Poveži svoj GitHub repo
3. Popuni:
   - Name: reunion-bot
   - Region: Frankfurt
   - Build Command: npm install
   - Start Command: node index.js
   - Instance Type: Free

## Korak 5: Dodaj Environment Variables

Dodaj sve iz config.json kao environment varijable.

## Korak 6: Deploy!

Klikni "Create" i bot će raditi 24/7 besplatno!
