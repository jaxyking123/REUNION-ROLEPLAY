ASSETS FOLDER - REUNION UTILITIES

Ovdje stavi sliku za welcome banner.

WELCOME BANNER:
- Stavi sliku ovdje i nazovi je "welcome-banner.png" ili "welcome-banner.jpg"
- Bot će automatski koristiti tu sliku u welcome poruci
- Preporučena veličina: 800x400 ili 1280x720

KAKO KORISTITI:
1. Kopiraj svoju sliku u ovaj folder
2. Preimenuj je u "welcome-banner.png" (ili .jpg)
3. Restartuj bota

