const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket sistem komande')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Postavi ticket sistem')
        .addChannelOption(option =>
          option.setName('kanal')
            .setDescription('Kanal za ticket panel')
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('close')
        .setDescription('Zatvori ticket')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'setup') {
      const channel = interaction.options.getChannel('kanal');

      const embed = new EmbedBuilder()
        .setTitle('🎫 REUNION UTILITIES - Ticket Sistem')
        .setDescription('Klikni na dugme ispod da otvoriš ticket.\n\nNaš support tim će ti uskoro odgovoriti!')
        .setColor('#5865F2')
        .setFooter({ text: 'REUNION UTILITIES' });

      const button = new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('Otvori Ticket')
        .setEmoji('🎫')
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(button);

      await channel.send({ embeds: [embed], components: [row] });
      await interaction.reply({ content: `✅ Ticket panel je postavljen u ${channel}`, ephemeral: true });
    }

    if (subcommand === 'close') {
      if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ Ova komanda se može koristiti samo u ticket kanalima!', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setTitle('🔒 Ticket Zatvoren')
        .setDescription(`Ticket zatvorio: ${interaction.user.tag}`)
        .setColor('#ED4245')
        .setTimestamp();

      await interaction.channel.send({ embeds: [embed] });
      await interaction.reply({ content: '⏳ Ticket će biti zatvoren za 5 sekundi...', ephemeral: true });

      setTimeout(() => {
        interaction.channel.delete();
      }, 5000);
    }
  }
};
