const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Whitelist sistem za upravljanje rolama')
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Dodaj korisnika na whitelist')
        .addUserOption(option =>
          option.setName('korisnik')
            .setDescription('Korisnik za whitelist')
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Ukloni korisnika sa whitelist-a')
        .addUserOption(option =>
          option.setName('korisnik')
            .setDescription('Korisnik za uklanjanje')
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('Prikaži sve whitelisted korisnike')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const whitelistPath = path.join(__dirname, '../whitelist.json');
    
    let whitelist = { whitelistedUsers: [] };
    if (fs.existsSync(whitelistPath)) {
      whitelist = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
    }

    if (subcommand === 'add') {
      const user = interaction.options.getUser('korisnik');
      
      if (whitelist.whitelistedUsers.includes(user.id)) {
        return interaction.reply({ content: `❌ ${user.tag} je već na whitelist-u!`, ephemeral: true });
      }

      whitelist.whitelistedUsers.push(user.id);
      fs.writeFileSync(whitelistPath, JSON.stringify(whitelist, null, 2));

      // Dodaj SECURITY WL rolu
      try {
        const member = await interaction.guild.members.fetch(user.id);
        if (config.securityWlRoleId && config.securityWlRoleId !== 'SECURITY_WL_ROLE_ID_HERE') {
          await member.roles.add(config.securityWlRoleId);
          console.log(`✅ SECURITY WL rola dodata ${user.tag}`);
        }
      } catch (error) {
        console.error('Greška pri dodavanju SECURITY WL role:', error);
      }

      await interaction.reply({ content: `✅ ${user.tag} je dodat na whitelist i dobio SECURITY WL rolu!`, ephemeral: true });
    }

    if (subcommand === 'remove') {
      const user = interaction.options.getUser('korisnik');
      
      if (!whitelist.whitelistedUsers.includes(user.id)) {
        return interaction.reply({ content: `❌ ${user.tag} nije na whitelist-u!`, ephemeral: true });
      }

      whitelist.whitelistedUsers = whitelist.whitelistedUsers.filter(id => id !== user.id);
      fs.writeFileSync(whitelistPath, JSON.stringify(whitelist, null, 2));

      // Ukloni SECURITY WL rolu
      try {
        const member = await interaction.guild.members.fetch(user.id);
        if (config.securityWlRoleId && config.securityWlRoleId !== 'SECURITY_WL_ROLE_ID_HERE') {
          await member.roles.remove(config.securityWlRoleId);
          console.log(`✅ SECURITY WL rola uklonjena od ${user.tag}`);
        }
      } catch (error) {
        console.error('Greška pri uklanjanju SECURITY WL role:', error);
      }

      await interaction.reply({ content: `✅ ${user.tag} je uklonjen sa whitelist-a i izgubio SECURITY WL rolu!`, ephemeral: true });
    }

    if (subcommand === 'list') {
      if (whitelist.whitelistedUsers.length === 0) {
        return interaction.reply({ content: '📋 Whitelist je prazan!', ephemeral: true });
      }

      const users = whitelist.whitelistedUsers.map(id => `<@${id}>`).join('\n');
      await interaction.reply({ content: `📋 **Whitelisted korisnici:**\n${users}`, ephemeral: true });
    }
  }
};
