const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setrole')
    .setDescription('Zameni sve role korisnika sa jednom rolom')
    .addUserOption(option =>
      option.setName('korisnik')
        .setDescription('Korisnik kome menjаš role')
        .setRequired(true)
    )
    .addRoleOption(option =>
      option.setName('rola')
        .setDescription('Nova rola')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('korisnik');
    const newRole = interaction.options.getRole('rola');
    
    try {
      const member = await interaction.guild.members.fetch(targetUser.id);
      
      // Ukloni sve role osim @everyone
      const rolesToRemove = member.roles.cache.filter(role => role.id !== interaction.guild.id);
      
      for (const role of rolesToRemove.values()) {
        await member.roles.remove(role);
      }
      
      // Dodaj novu rolu
      await member.roles.add(newRole);
      
      await interaction.reply({ 
        content: `✅ Sve role uklonjene od ${targetUser.tag} i dodata rola ${newRole.name}`, 
        ephemeral: true 
      });
      
      console.log(`✅ ${interaction.user.tag} zamenio role za ${targetUser.tag} sa ${newRole.name}`);
    } catch (error) {
      console.error('Greška pri zameni rola:', error);
      await interaction.reply({ 
        content: '❌ Greška pri zameni rola!', 
        ephemeral: true 
      });
    }
  }
};
