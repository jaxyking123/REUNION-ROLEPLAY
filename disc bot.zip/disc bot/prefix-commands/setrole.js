module.exports = {
  name: 'setrole',
  description: 'Zameni sve role korisnika sa jednom rolom',
  async execute(message, args) {
    if (!message.member.permissions.has('ManageRoles')) {
      return message.reply('❌ Nemaš permisije za ovu komandu!');
    }

    // Format: !setrole @user ROLE_ID
    if (args.length < 2) {
      return message.reply('❌ Koristi: `!setrole @korisnik ROLE_ID`');
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply('❌ Taguj korisnika!');
    }

    const roleId = args[1];
    const newRole = message.guild.roles.cache.get(roleId);
    
    if (!newRole) {
      return message.reply('❌ Nevažeći ID role!');
    }

    try {
      const member = await message.guild.members.fetch(targetUser.id);
      
      // Ukloni sve role osim @everyone
      const rolesToRemove = member.roles.cache.filter(role => role.id !== message.guild.id);
      
      for (const role of rolesToRemove.values()) {
        await member.roles.remove(role);
      }
      
      // Dodaj novu rolu
      await member.roles.add(newRole);
      
      await message.reply(`✅ Sve role uklonjene od ${targetUser.tag} i dodata rola ${newRole.name}`);
      
      console.log(`✅ ${message.author.tag} zamenio role za ${targetUser.tag} sa ${newRole.name}`);
    } catch (error) {
      console.error('Greška pri zameni rola:', error);
      await message.reply('❌ Greška pri zameni rola!');
    }
  }
};
