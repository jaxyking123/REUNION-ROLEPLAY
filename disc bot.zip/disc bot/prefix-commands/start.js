const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');

module.exports = {
  name: 'start',
  description: 'Pokreni ticket sistem',
  async execute(message, args) {
    if (!message.member.permissions.has('ManageChannels')) {
      return message.reply('❌ Nemaš permisije za ovu komandu!');
    }

    const embed = new EmbedBuilder()
      .setTitle('🎫 REUNION UTILITIES - Setup')
      .setDescription('U koji kanal želiš da postavim ticket panel?\n\nTaguj kanal ili napiši ID kanala.')
      .setColor('#5865F2')
      .setFooter({ text: 'Imaš 30 sekundi da odgovoriš' });

    await message.reply({ embeds: [embed] });

    const filter = m => m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000, max: 1 });

    collector.on('collect', async m => {
      let channel;
      
      // Proveri da li je tagovan kanal
      if (m.mentions.channels.first()) {
        channel = m.mentions.channels.first();
      } else {
        // Proveri da li je ID
        channel = message.guild.channels.cache.get(m.content);
      }

      if (!channel || channel.type !== ChannelType.GuildText) {
        return m.reply('❌ Nevažeći kanal! Pokušaj ponovo sa `!start`');
      }

      // Kreiraj ticket panel sa razlozima
      const ticketEmbed = new EmbedBuilder()
        .setTitle('🎫 REUNION UTILITIES - Ticket Sistem')
        .setDescription('Odaberi razlog za otvaranje ticketa klikom na odgovarajuće dugme:')
        .addFields(
          { name: '👮 Žalba na Admina', value: 'Prijavi nepravilno ponašanje admina', inline: false },
          { name: '🎮 Žalba na Igrača', value: 'Prijavi igrača koji krši pravila', inline: false },
          { name: '🐛 Prijava Buga', value: 'Prijavi bug ili tehnički problem', inline: false },
          { name: '❔ Pitanja', value: 'Postavi pitanje ili zatraži pomoć', inline: false },
          { name: '💰 Donacija', value: 'Pitanja o donacijama i kupovini', inline: false }
        )
        .setColor('#5865F2')
        .setFooter({ text: 'REUNION UTILITIES' });

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_admin')
          .setLabel('Žalba na Admina')
          .setEmoji('👮')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('ticket_player')
          .setLabel('Žalba na Igrača')
          .setEmoji('🎮')
          .setStyle(ButtonStyle.Primary)
      );

      const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_bug')
          .setLabel('Prijava Buga')
          .setEmoji('🐛')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('ticket_question')
          .setLabel('Pitanja')
          .setEmoji('❔')
          .setStyle(ButtonStyle.Secondary)
      );

      const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_donation')
          .setLabel('Donacija')
          .setEmoji('💰')
          .setStyle(ButtonStyle.Secondary)
      );

      await channel.send({ embeds: [ticketEmbed], components: [row1, row2, row3] });
      
      const successEmbed = new EmbedBuilder()
        .setTitle('✅ Uspešno!')
        .setDescription(`Ticket panel je postavljen u ${channel}`)
        .setColor('#57F287');

      await m.reply({ embeds: [successEmbed] });
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        message.channel.send('⏱️ Vreme je isteklo! Pokušaj ponovo sa `!start`');
      }
    });
  }
};
