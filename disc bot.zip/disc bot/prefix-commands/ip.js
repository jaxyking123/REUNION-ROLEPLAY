const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ip',
  description: 'Prikaži IP adresu FiveM servera',
  async execute(message, args) {
    const embed = new EmbedBuilder()
      .setTitle('🎮 Reunion Roleplay - Server IP')
      .setDescription('**Pridruži se serveru:**\n\n`(vas ip five m servera)`')
      .setColor('#5865F2')
      .addFields(
        { name: '📋 Kako se povezati?', value: 'Kopiraj IP adresu i zalepi je u FiveM Direct Connect', inline: false },
        { name: '🔗 FiveM', value: 'Otvori FiveM > F8 > `connect (vas ip five m servera)`', inline: false }
      )
      .setFooter({ text: 'Reunion Roleplay' })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  }
};
